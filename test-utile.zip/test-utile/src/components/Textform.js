import React,{useState} from 'react'

export default function Textform(props) {
  const handleUpClick=()=>{
    // console.log("Uppercase was Clicked" + text);
    let newtext = text.toUpperCase();
    setText(newtext);
    props.showAlert("Converted to uppercase!","success")
  }
  const handleClearClick=()=>{
    // console.log("Uppercase was Clicked" + text);
    let newtext = ('');
    setText(newtext);
    props.showAlert("Text cleared!","success")
  }
  const handleLoClick=()=>{
    // console.log("Uppercase was Clicked" + text);
    let newtext = text.toLowerCase();
    setText(newtext);
    props.showAlert("Converted to lowercase!","success")
  }
  const handleOnchange=(event)=>{
    // console.log("Handle was Clicked")
    setText(event.target.value)
  }
  const [text, setText] = useState('');
  return (
  <> 
<div className="container my-2" style = {{color: props.mode === 'dark'?'white':'black'}}>
  <h2>Enter the text to analyze below</h2>
  <textarea className="form-control" value= {text}  style = {{backgroundColor: props.mode === 'dark'?'#242c33':'white',color: props.mode === 'dark'?'white':'black'}} onChange={handleOnchange} id="exampleFormControlTextarea1" rows="8"></textarea>
    <button className="btn btn-primary my-2 mx-1" onClick={handleUpClick}>Covert to Uppercase</button>
    <button className="btn btn-primary my-2 mx-1" onClick={handleLoClick}>Covert to Lowercase</button>
    <button className="btn btn-primary my-2 mx-1" onClick={handleClearClick}>Clear Text</button>
</div>
<div className='container my-2' style = {{color: props.mode === 'dark'?'white':'black'}}>
  <h2>Your text summary</h2>
  <p>{text.split(" ").filter((element)=>{return element.length!==0}).length} words,{text.length} characters</p>
  <p>{0.008 * (text.split(" ").length)} Minutes read </p>
  <h2>Preview</h2>
  <p>{text.length>0?text:"Enter something in the textbox above to preview it here"}</p>
</div>
</>
  )
}
